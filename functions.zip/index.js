
const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

// exports.fun = functions.https.onRequest((req, res) => { //lat, lng :100 m = 0.0011111 lng
//     const range = 0.0011111;
//     lat = req.query.lat;
//     lng = req.query.lng;

//     const category = req.query.category;

//     const D = [];

//     const store = admin.firestore().collection('Restaurant')
//     .where('category', '==', category)
//     .orderBy('score', 'desc').get()
//     .then(snapshot => {
//             snapshot.forEach(doc => {
//             if(parseFloat(doc.data().lat) < parseFloat(lat)+ parseFloat(3*range) && parseFloat(doc.data().lat) >  parseFloat(lat)- parseFloat(3*range)
//             && parseFloat(doc.data().lng) < parseFloat(lng)+ parseFloat(3*range) && parseFloat(doc.data().lng) >  parseFloat(lng)- parseFloat(3*range)){
            
//                 const data = {
//                     id: doc.id,
//                     category: doc.data().category,
//                     lat:doc.data().lat,
//                     lng:doc.data().lng,
//                     location:doc.data().location,
//                     name:doc.data().name,
//                     score:doc.data().score
//                 }
               
//                 if(!D.find((item, idx) => {
//                     if(item.name === data.name){
//                         return true;
//                     }else{
//                         return false;
//                     }
//                 }))
//                 {
//                     D.push(data)
//                 }
//             }
//             if(D.length >3){
//                 res.send({recommend : D})
//             }
//         })
//         res.send({recommend : D})
     
//         return ;
//     })
//     .catch(error => {
//         console.log(error)
//     })

// })



exports.fun = functions.https.onRequest((req, res) => { //lat, lng :100 m = 0.0011111 lng
    const range = 0.0011111;
    lat = req.query.lat;
    lng = req.query.lng;

    const category = req.query.category;

    const D = [];
    
    const result = []
    var i = false

    const store = admin.firestore().collection('Restaurant')
    .where('category', '==', category)
    .orderBy('score', 'desc').get()
    .then(snapshot => {
        const promises = []

        snapshot.forEach(doc => {
            if(i) return false;
            if(parseFloat(doc.data().lat) < parseFloat(lat)+ parseFloat(2*range) && parseFloat(doc.data().lat) >  parseFloat(lat)- parseFloat(2*range)
            && parseFloat(doc.data().lng) < parseFloat(lng)+ parseFloat(2*range) && parseFloat(doc.data().lng) >  parseFloat(lng)- parseFloat(2*range)){
            
                const data = {
                    id: doc.id,
                    category: doc.data().category,
                    lat:doc.data().lat,
                    lng:doc.data().lng,
                    location:doc.data().location,
                    name:doc.data().name,
                    score:doc.data().score
                }
               
                if(!D.find((item, idx) => {
                    if(item.name === data.name){
                        return true;
                    }else{
                        return false;
                    }
                }))
                {
                    const p = admin.firestore().collection('guest').where('name', '==', data.name).orderBy('score', 'desc').get()
                    promises.push(p)
                    D.push(data)
                }
            }

            if(D.length >=5) {
                i=true
           }
        })
        
        return Promise.all(promises);
    })
    .then(nameSnapshot =>{
        nameSnapshot.forEach(nameSnap => {
            var cnt = 0;
            var sum = 0;
            var name = "";
            
            nameSnap.forEach(shot =>{
                const data = {
                    name:shot.data().name,
                    score:shot.data().score
                }
                cnt+=1
                sum+=parseInt(shot.data().score)
                name = shot.data().name
            })

            var idx = D.findIndex((item, idx) =>{
                return item.name === name
            })
            if(idx<0) return false; // continue

            sum = parseInt(sum/cnt)

            var newsum = (sum + parseInt((D[idx].score).slice(-0, -1)))/2
            D[idx].score = String(newsum) + "점"
        })
        
        D.sort((a,b) => {
            return parseInt((b.score).slice(-0, -1)) - parseInt((a.score).slice(-0, -1))
        })
        D.forEach(e =>{
            result.push(e)
            if(result.length>=3)
            {
                res.send({recommend : result})
            }
        })

        res.send({recommend : result})
        return ; 
    })
    .catch(error => {
        console.log(error)
    })

})

